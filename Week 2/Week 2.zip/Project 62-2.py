#get user input for cube edge
#do the math
#print results

cubeEdge = float(input('Enter the length of the cubes edge in feet: '))
area = (cubeEdge * cubeEdge) * 6
print("The surface area is " + str(area) + " square " + "feet")
