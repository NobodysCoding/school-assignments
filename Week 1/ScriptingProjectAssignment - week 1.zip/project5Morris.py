base = int(input("Enter with base: "))
height = int(input("Enter with height: "))
area = .5 * base * height
print("The area is", area, "square units.")
