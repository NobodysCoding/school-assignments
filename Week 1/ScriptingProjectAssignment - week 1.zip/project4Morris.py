width = int(input("Enter with width: "))
length = int(input("Enter with length: "))
area = width * length
print("The area is", area, "square units.")
