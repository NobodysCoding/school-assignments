print("Charles Morris")
print("45 NE 67th st. OKC, Ok 73105")
print("405-534-0110")
